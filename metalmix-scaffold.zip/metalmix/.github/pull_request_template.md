## What changed

<!-- One or two sentences. -->

## Why

<!-- The problem this solves, or the milestone it moves forward. -->

## How it was tested

- [ ] Test host on the dev Mac (chip / macOS: )
- [ ] In the game on the test Mac (chip / macOS / game version: )
- [ ] Not needed (docs or tooling only)

## Docs

- [ ] Updated the matching page in `docs/` (which: )
- [ ] No docs change needed, because:

## Safety

- [ ] Every new hook calls the original on every path
- [ ] Nothing new runs on the render thread that could block
- [ ] Anything that touches the game runs the save backup first
