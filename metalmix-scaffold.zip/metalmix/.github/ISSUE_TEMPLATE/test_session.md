---
name: Test session report
about: Results from a test session on the test Mac
labels: testing
---

**Build** (commit from `mmctl status` or `core/build-commit.txt`):

**Game version:**

**Save backup ran?** yes / skipped (no changes) / failed

**What was tested**

**Smoke checklist** (copy from docs/testing.md and tick)

**Problems seen**

**Report folder in metalmix-testbench** (if `mm-report.command` was used):
