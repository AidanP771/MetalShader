---
name: Bug report
about: Something went wrong with MetalMix
labels: bug
---

**What happened**

**What you expected**

**Steps to reproduce**

1.
2.

**Your Mac**

- Model and chip:
- macOS version:
- The Sims 4 version (main menu, bottom corner):
- MetalMix version:

**Logs**

Run this in Terminal and attach the file it creates on your Desktop:

```sh
log show --predicate 'subsystem == "io.metalmix"' --last 1h > ~/Desktop/metalmix-log.txt
```

**Did you try turning MetalMix off?** (Hold Option while the game starts.) Did
the problem go away?
